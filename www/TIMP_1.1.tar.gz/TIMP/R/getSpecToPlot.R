"getSpecToPlot" <-
function (E, cohmax, cohcol, plotcohcolspec = TRUE) 
{
	if(plotcohcolspec) {
	 if(length(cohcol) > 0){
	   E[, cohcol] <- E[, cohcol] * cohmax 
	 }
	}
	else {
	     E <- E[, -cohcol]
	}
	E
}

