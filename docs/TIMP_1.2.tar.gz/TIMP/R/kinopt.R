"kinopt" <-
function(...){
	new("kinopt", ...)
}

