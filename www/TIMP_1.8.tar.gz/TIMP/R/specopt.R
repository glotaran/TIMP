"specopt" <-
function(...){
	new("specopt",...)
}

