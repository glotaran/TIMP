"het" <-
function(...){
	new("het", ...)
}

