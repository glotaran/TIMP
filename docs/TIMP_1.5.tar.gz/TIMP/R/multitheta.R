"multitheta" <-
function(...) { 
	   new("multitheta", ...)
}

