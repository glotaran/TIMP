"plotKinSpec" <-
function(multimodel, t, plotoptions, newplot=TRUE, max_x2=NA, min_x2=NA, 
ylim=vector(), kinspecerr=FALSE)
{
	m <- multimodel@modellist
	resultlist <- multimodel@fit@resultlist 
	if(newplot) {
	   x11()
	   par(oma = c(0,0,4,0),cex=1.5)
	   kinspecerr <- plotoptions@kinspecerr
	}
	if(is.na(max_x2) || is.na(max_x2))
			 withlim <- FALSE 
	else		 withlim <- TRUE
	## is x2 decreasing? assume answer same for all datasets 
	x2_decr <- if(m[[1]]@x2[1] < m[[1]]@x2[m[[1]]@nl]) FALSE
	       else TRUE
        allx2 <- allx <- vector() 
	for(i in 1:length(m)) {
	  allx2 <- append(allx2, m[[i]]@x2) 
	  allx <- append(allx, m[[i]]@x)
	}
	specList <- list() 
	maxs <- mins <- maxspecdim <- 0

	specList <- getSpecList(multimodel, t)

	for(i in 1:length(m)) {
		      cohcol <- m[[i]]@cohcol 
		      spec <- getSpecToPlot(specList[[i]], 1, 
		      cohcol)
		      
		      if(length(m[[i]]@cohspec) != 0) 
			   spec <- spec[,-cohcol] 
		      specList[[i]] <- spec
		      maxs <- max(maxs, max(spec))
		      mins <- min(mins, min(spec))
		      maxspecdim <- max(maxspecdim, dim(spec)[2])
	}	      			      
	if(!withlim) 
		xlim <- c(min(allx2),max(allx2))
	else xlim <- c(min_x2, max_x2)
	if(length(plotoptions@xlimspec) == 2) 
		xlim <- plotoptions@xlimspec
	if(length(plotoptions@xlimspec) == 2) 
		ylim <- plotoptions@ylimspec
	if(length(ylim) == 0) 
		ylim <- c(mins, maxs)

        if(!plotoptions@specinterpol) {
	  
		    
	if(kinspecerr) {
	   errtList <- getSpecList(multimodel, t, TRUE) 
	   for(i in 1:length(m)) {
	      if(length(m[[i]]@cohspec) != 0) 
			   errtList[[i]] <- errtList[[i]][,-m[[i]]@cohcol] 
	      for(j in 1:dim(specList[[i]])[2])
		      plotCI(m[[i]]@x2, specList[[i]][,j], 
		      uiw=errtList[[i]][,j], 
		      main = "", xlab = plotoptions@xlab,
		      ylab="amplitude", lty = i, xlim =xlim,ylim=ylim,
		      col = j, sfrac = 0,  type="l", gap = 0,
		      add = !(i == 1 &&	j == 1), labels = "")
 	   }
	 }
	 else 
	      	for(i in 1:length(m))
		      matplot(m[[i]]@x2, specList[[i]], type = "l", 
		      main = "",  xlab = plotoptions@xlab, ylab="amplitude", 
		      lty = i, xlim =xlim,ylim=ylim,  
		      add = !(i ==1))
         }
	 else {
	      x2speccomp <- vector("list", maxspecdim)
	      speccomp <- vector("list", maxspecdim)
	      for(i in 1:length(m)){
		      for(j in 1:dim(specList[[i]])[2]) { 		
			    speccomp[[j]] <- append(speccomp[[j]], 
					     specList[[i]][,j] )
			    x2speccomp[[j]] <- append(x2speccomp[[j]],
					       m[[i]]@x2)
			}
	       }
	       newSpec <- vector("list", maxspecdim)
	       newSpecx2 <-  vector("list", maxspecdim)
	       for(j in 1:maxspecdim) {	    
		      xx<- sort(x2speccomp[[j]], index.return = TRUE) 
		      xy <- speccomp[[j]][xx$ix]
		      newSpec[[j]] <- xy 
		      newSpecx2[[j]] <- xx$x
	       }
	       for(i in 1:length(m)) 
		      matplot(m[[i]]@x2, specList[[i]], type = "p",
		      pch = if(plotoptions@specinterpolpoints) 25-i else "",  
		      main = "",  xlab = plotoptions@xlab, ylab="amplitude", 
		      lty = i, xlim =xlim,ylim=ylim,  
		      add = !(i ==1))
		
		for(j in 1:maxspecdim) {	    
		     xx <- newSpec[[j]]  
		     if(length(plotoptions@smoothwave) !=0) {
		      if(j %in% plotoptions@smoothwavecomp) { 
		        xw <- plotoptions@smoothwave 
		     
		      for(i in 1:length(xw)) {
			    xx[xw[[i]]] <- lowess(xx[xw[[i]]],
		            f=plotoptions@smoothwavepar/length(xw[[i]]) )$y
		      } 
		      
		       }
		      }
		      lines(newSpecx2[[j]], xx, col=j) 
		      if(plotoptions@writesmoothwave) { 
		
		      write.table(xx, file=paste(plotoptions@makeps,
		      "_smoothedspectracomponent_", j, ".txt", sep=""), quote = FALSE,
		      row.names = newSpecx2[[j]])
	              }
	    }

	   }
         
	 if (newplot && length(plotoptions@title) != 0) {
            mtext(plotoptions@title, side = 3, outer = TRUE, 
                line = 1)
            par(las = 2)
        }
	abline(0,0)
	if (length(plotoptions@makeps) != 0) {
            dev.print(device = postscript, file = paste(plotoptions@makeps, 
                "_kinspec.ps", sep = ""))
        }

}

