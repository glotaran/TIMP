"baseCortime" <-
function (data, basev) 
{
    psisim <- data@psi.df
    tmin <- basev[1]
    tmax <- basev[2]
    lmin <- basev[3]
    lmax <- basev[4]
    
    for (j in tmin:tmax) {
        baseline <- sum(psisim[j, lmin:lmax])/(length(lmin:lmax))
        psisim[j, ] <- psisim[j, ] - baseline
    }
    data@psi.df <- psisim
    data
}

