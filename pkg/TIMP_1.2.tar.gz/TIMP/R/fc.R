"fc" <-
function(...){
	new("fc", ...)
}

