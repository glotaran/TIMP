"make.table" <-
function(nr, nc) {

    x11()	     
    par(omi=c(0,0,0,0), mgp=c(2,1,0), 
	    mai=c(.5,.5,.5,.25))  
    plot(c(.5, nc*.7 + 1), c(.5, -(.7*nr + 1)),
         type="n", xlab="", ylab="", axes=FALSE)

}

