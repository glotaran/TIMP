"amp" <-
function(...){
	new("amp",...)
}

