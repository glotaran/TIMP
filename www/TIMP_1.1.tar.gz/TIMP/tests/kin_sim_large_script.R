##############################
## Kinetic model on large simulated dataset. 
##############################

##############################
## load TIMP
##############################

require(TIMP)

# read data
ser1<-readData("sim1.txt")

## sel_lambda argument says to take wavelengths 1-460 from the 
## vector of wavelengths ser1@x2 

## to see what is inside object ser1 
slotNames(ser1)

## times 
ser1@x

## times 1- 100

ser1@x[1:100] 

## locations (wavelengths) 
ser1@x2

## the data as a matrix [times, locations]

ser1@psi.df 

## get the 2nd row, 1st column 

ser1@psi.df[2 , 1]

## get the 2nd row (all) 
ser1@psi.df[2, ]

## get the 2nd column (all) 
ser1@psi.df[ ,2]

## plot the row 2: the first input to "plot" is the labels, the 2nd is 
## the thing to plot 

plot(ser1@x2, ser1@psi.df[2, ]) 

## make the plot nicer

help(plot)  

plot(ser1@x2, ser1@psi.df[2, ], type = "b") 

## Preprocess to select wavelength 1-460

ser2<-preProcess(data = ser1, sel_lambda=c(1,460))

## Specify initial model 

model1<- initModel(mod_type = "kin", 
kinpar=c(0.6486961246E-01), lambdac = 500, 
irfpar=c(57.47680283, 1.9), 
parmu = list(c(-2.639, 3.7),c(-2.639, 3.7)), 
seqmod=FALSE,clp0 = list(list(comp = 1, low = 300, high = 421), 
list(comp = 2, low = 426, high = 1000)), positivepar=c("kinpar"),
makeps="Sergey data", title="Ser", 
cohspec = list(type = "freeirfdisp"))

## fit the model 

serRes<-fitModel(list(ser2), list(model1), 
opt=kinopt(iter=1, linrange = 20,
makeps = "ser", 
selectedtraces = seq(1, ser2@nl, by=30),
xlab = "time (ps)", ylab = "wavelength"))

