"massopt" <-
function(...){
	new("massopt", ...)

}

