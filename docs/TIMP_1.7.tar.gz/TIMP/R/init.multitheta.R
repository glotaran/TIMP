setClass("multitheta", representation(th = "list"))

