"dat" <-
function (...) 
{
    new("dat", ...)
}

