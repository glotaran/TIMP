setClass("fit", representation(resultlist = "list", 
nlsres = "list", rss = "numeric"), prototype = list(
resultlist = list(), 
nlsres = list(), 
rss = 0)) 
