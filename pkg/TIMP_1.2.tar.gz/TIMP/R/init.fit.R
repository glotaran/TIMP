"init.fit" <-
function () 
{
setClass("fit", representation(resultlist = "list", 
nlsres = "list")) 

}