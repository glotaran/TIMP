"getDiffTheta" <- function(th, mod) {
	modellist <- mod@modellist 
	modeldiff <- mod@modeldiffs
	parorder <- list()
	if(length(modeldiff$change) != 0) {
		thA <- getDiffThetaChange(th, mod)
		th <- thA$th
		.currModel@parorderchange <<- thA$parorder
	}
	if(length(modeldiff$free)!=0 || length(modeldiff$add) !=0)
		for(diff in append(mod@modeldiffs$free, mod@modeldiffs$add)){ 
		        
			  if(length(diff$ind) == 2) 
			     partmp <- slot(modellist[[diff$dataset[1] ]], 
	                     diff$what)[[diff$ind[1]]][diff$ind[2]]
			  else 
			     partmp <- slot(modellist[[diff$dataset[1]]], 
	                     diff$what)[diff$ind]
			  if(diff$what %in% modellist[[diff$dataset[1]]]@positivepar)
			     partmp <- log(partmp)
			  ind <- (length(th) + 1):(length(th) + length(partmp))
			  parorder[[length(parorder)+1]] <- list(name=diff$what,
			     ind=ind, rm=vector(), dataset=diff$dataset, indm=diff$ind)
		
			  th <- append(th, partmp)
			 
                }          
        if(length(modeldiff$rel)!=0)
		for(diff in modeldiff$rel)
		    if(length(diff$start) != 0) {
			  ind <- (length(th) + 1):(length(th) + length(diff$start))
			  parorder[[length(parorder)+1]] <- list(name=diff$what,
			  ind=ind, rm=vector(), dataset=diff$dataset, indm=diff$ind)
			  th <- append(th, diff$start)

	            }
        if(length(modeldiff$dscal) != 0) {
		for(i in 1:length(modeldiff$dscal)) {
		      j <- modeldiff$dscal[[i]]$to 
		      if(length(modellist[[j]]@drel) != 0){ 
				fixed <- modellist[[j]]@fvecind
				prel <- modellist[[j]]@pvecind 
				removepar <- sort(append(fixed[["drel"]], prel[["drel"]]))
				parapp <- if(length(removepar)!=0)  
				       unlist(slot(modellist[[j]], 
					      "drel"))[-removepar] 
				       else unlist(slot(modellist[[j]], 
					    "drel"))
				if(length(parapp) != 0)
				    ind <- (length(th) + 1):(length(th) + length(parapp))
				else ind <- vector()
				parorder[[length(parorder)+1]] <- list(name="drel",
				ind=ind, rm=removepar, dataset=j, 
				indm=(1:length(modellist[[j]]@drel)))
				th <- append(th, parapp)
			}
	        }
       }
       .currModel@parorderdiff <<- parorder
       th
}

