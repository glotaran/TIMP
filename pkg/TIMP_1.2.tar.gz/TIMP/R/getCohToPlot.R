"getCohToPlot" <-
function () 
{
}

