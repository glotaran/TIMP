"l2nu" <- 
function(lambda)
{
	10^7/lambda
}
