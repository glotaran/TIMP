"theta" <-
function(...){
	new("theta", ...)
}

