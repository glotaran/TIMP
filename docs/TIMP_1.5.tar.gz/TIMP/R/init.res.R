setClass("res", representation(cp = "list", resid = "list", 
fitted = "list", irfvec = "list", cohirf = "list", std_err_clp= "list"), 
prototype = list(cp = list(), resid = list(), fitted = list(), 
irfvec = list(), cohirf=list() , std_err_clp = list() ) )
