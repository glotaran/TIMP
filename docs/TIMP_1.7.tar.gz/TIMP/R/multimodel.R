"multimodel" <-
function(...) { 
	   new("multimodel", ...)
}

