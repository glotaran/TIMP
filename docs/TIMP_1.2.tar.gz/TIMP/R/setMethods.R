"setMethods" <-
function () 
{
	set_residPart_kin()
	set_residPart_spec()
	set_getClpindepX_kin()
	set_getClpindepX_spec()
	set_plotter_kin()
	set_plotter_spec()
}




