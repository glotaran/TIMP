"getFinished" <-
function (finished) 
{
	if(finished)
		f <- list(cp = list(), resid = list(), fitted = list(), 
		     irfpar = list()) 
	else 
		f <- list() 

	f
		 
}

