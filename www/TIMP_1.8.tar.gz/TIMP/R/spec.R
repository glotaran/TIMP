"spec" <-
function(...){
	new("spec",...)
}

