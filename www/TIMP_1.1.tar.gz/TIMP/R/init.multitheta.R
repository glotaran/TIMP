"init.multitheta" <-
function() { 
setClass("multitheta", representation(th = "list"))
}

