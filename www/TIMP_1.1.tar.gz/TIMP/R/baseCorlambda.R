"baseCorlambda" <-
function (data, basev) 
{
    psisim <- data@psi.df
    tmin <- basev[1]
    tmax <- basev[2]
    #lmin <- which(data@x2 >= basev[3])[1]
    #lmax <- which(data@x2 < basev[4])[length(which(data@x2 < 
    #    basev[4]))]
    lmin <- basev[3]
    lmax <- basev[4]

    for (j in lmin:lmax) {
        baseline <- sum(psisim[tmin:tmax, j])/(length(tmin:tmax))
        psisim[, j] <- psisim[, j] - baseline
    }
    data@psi.df<- psisim
    data
}

