"fit" <-
function(...){
	new("fit", ...)
}

