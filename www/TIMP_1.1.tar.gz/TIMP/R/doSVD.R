"doSVD" <-
function (x, numleft, numright)
#doSVD
{
	svdx<-La.svd(as.matrix(x),nu=nrow(x),nv=ncol(x))
	
	list(values=svdx$d, left=svdx$u[,1:numleft], 
             right=svdx$vt[1:numright,])

}

