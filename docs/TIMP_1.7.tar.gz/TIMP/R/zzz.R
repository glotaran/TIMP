".onLoad" <- function (lib, pack)
{
	library.dynam(pack, pack, lib)

}
