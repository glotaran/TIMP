"opt" <-
function (...) 
{
    new("opt", ...)
}

