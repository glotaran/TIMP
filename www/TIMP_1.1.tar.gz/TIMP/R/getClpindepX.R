"getClpindepX" <-
structure(function(model, theta)
        standardGeneric("getClpindepX")
, class = structure("standardGeneric", package = "methods"), generic = structure("getClpindepX", package = ".GlobalEnv"), package = ".GlobalEnv", group = list(), valueClass = character(0), signature = c("model", 
"theta"), default = structure(list(), methods = list(), argument = quote(model), allMethods = list(), class = structure("MethodsList", package = "methods")), skeleton = quote(function (model, 
    theta) 
stop("invalid call in method dispatch to 'getClpindepX' (no default method)", 
    domain = NA)(model, theta)))
