PPViewer 1.0.0 source files for NI LabVIEW 8.2.1
LV Project -- PPViewer.lvprogj
Main VI -- PPViewer.vi

If you want to get sources for other LabVIEW version, please contact me (Ilya Stepanenko, <ilstep@gmail.com>)
See http://www.nat.vu.nl/~kate/TIMP/ppviewer.html for updates.