"mass" <-
function (...) 
{
    new("mass", ...)
}

