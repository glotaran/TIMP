"init.fc" <-
function(){
setClass("fc", representation("dat", fc = "list"))
}

