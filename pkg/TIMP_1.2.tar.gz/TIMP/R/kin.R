"kin" <-
function(...){
	new("kin", ...)
}

