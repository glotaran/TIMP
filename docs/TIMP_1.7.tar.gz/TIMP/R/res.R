"res" <-
function(...){
	new("res", ...)
}

